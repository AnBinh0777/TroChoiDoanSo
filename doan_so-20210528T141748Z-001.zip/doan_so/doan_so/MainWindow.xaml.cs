﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading.Tasks;
namespace doan_so
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        
        private void txtkiem_tra_Click(object sender, RoutedEventArgs e)
        {
            Random rd = new Random();
        int so_may = rd.Next(10);
        int so_lan_doan = 0;
             while (true)
            {
                
                
                so_lan_doan = so_lan_doan + 1;
                if (so_lan_doan==20)
                {
                    MessageBox.Show("Bạn đã đoán sai quá nhiều"+"\n"+"Chúc bạn may mắn lần sau", "Thông báo");
                   
                }
                else
                {
                    if(int.Parse(txtso_nhap.Text)==so_may)
                {
                    MessageBox.Show("Bạn thật sự rất thông minh"+ "\n"+"MINH LONG THẬT ĐẸP TRAI","Thông báo");
                  
                }
                else
                {
                    if(int.Parse(txtso_nhap.Text)>so_may)
                    {
                        MessageBox.Show("Bạn đã đoán số lớn hơn rồi" + "\n" + "MINH NGỌC THẬT ĐẸP GÁI", "Thông báo");
                    }
                    else
                    {
                        MessageBox.Show("Bạn đã đoán số bé hơn rồi"+"\n"+"Chị Mi rất xinh đẹp","Thông báo");
                    }

                }
            }

            }


        }



        }
    }

